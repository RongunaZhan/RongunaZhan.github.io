<Html>
<Head>
<title>Assignment2</title>
    <Meta NAME="" CONTENT="">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
        integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <!-- Optional theme -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap-theme.min.css"
        integrity="sha384-6pzBo3FDv/PJ8r2KRkGHifhEocL+1X2rVCTTkUfGk7/0pbek5mMa1upzvWbrUbOZ" crossorigin="anonymous">
    <link rel="stylesheet" href="./index.less">
<?PHP include("header.php")?>
</head>
<body>
        
<!-- header-title- -->
    <?php echo "<hr class=\"featurette-divider\">
    <div class=\"page-header container\">
        <h1 class=\"text-uppercase\"><strong>Assignment2: Protal Design</strong> <small>Puala & Rong Zhan</small></h1>
    </div>";?>
    <!-- Navigation Menu -->
    <?php echo "<nav class=\"navbar navbar-default navbar-fixed-top\">
        <div class=\"container\">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class=\"navbar-header\">
                <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\"
                    data-target=\"#bs-example-navbar-collapse-1\" aria-expanded="false">";?>
                    <?php echo "<span class=\"sr-only\">Toggle navigation</span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                    <span class=\"icon-bar\"></span>
                </button>
            </div>";?>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <?php echo "<div class=\"collapse navbar-collapse\" id=\"bs-example-navbar-collapse-1\">
                <!-- Dropdown -->
                <ul class=\"nav navbar-nav navbar-right\">
                    <li class=\"dropdown\">
                        <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup="true"
                            aria-expanded="false">Wireframes<span class=\"caret\"></span></a>";?>
                        <?php echo "<ul class=\"dropdown-menu\">
                            <li><a href=\"#wireframes-b\">Balsamiq wireframes</a></li>
                            <li><a href=\"#wireframes-d\">Documentation</a></li>
                        </ul>
                    </li>";?>
                    <?php echo "<li class=\"dropdown\">
                        <a href=\"#" class="dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup="true"
                            aria-expanded="false">Design the final steps<span class=\"caret\"></span></a>";?>
                        <?php echo "<ul class=\"dropdown-menu\">
                            <li><a href=\"#design-b\">Balsamiq wireframes</a></li>
                            <li><a href=\"#design-d\">Documentation</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>";?>

    <!-- Wireframes -->
    <?php echo "<div class=\"page-header container\">
        <h1>WIREFRAMES</h1>
        <hr>
        <div class=\"container\">
            <h2 id=\"wireframes-b\">Balsamiq wireframes</h2><a href=\"./20220228 DM6103 Balsamiq(1).bmpr\">learn more</a>
            <hr>
            <hr>
            <h4 id=\"wireframes-d\"> This project was a wireframe for the creation of a project submitted by a film website, which was done
                by Rong and Puala. It consists of 17 pages, namely Home Page, Sign Up, Sign Up With Email, Add a
                Project, Project Success, Edit Created Project, Edit Project Privacy, Marketing Options, Project List,
                FilmFreeway-Browse Festival, Submitting Your Project, Submitting Your Project (Supplementary Question),
                View Festival, Checkout, Final Step (Failed), Final Step (Successful), and Log Out. By organizing and
                producing wireframes, we can learn the basic lines and operations of adding a project on The FilmFreeway
                - submitting a project - completing the submission (design) of the entire process.</h4><a
                href=\"./rongzhan-document.docx\">learn more</a>
            <hr>
            <hr>
            <h4> First of all, add the project, the specific addition process is that after the user completes the
                registration, the web page will automatically pop up Add a Project, in this page the user needs to fill
                in the Project Information, Submitter information，Credits information, Specifications and
                Screenings/Distribution. Then save the project, you can also log in and add a project to the page
                through the My Project in the top bar of the web page. </h4><a href=\"./rongzhan-document.docx\">learn
                more</a>
            <hr>
            <div class=\"container\">
                <!-- banner -->
                <div id=\"carousel-example-generic\" class=\"carousel slide contanier\" data-ride=\"carousel\">
                    <!-- Indicators -->
                    <ol class=\"carousel-indicators\">
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"3\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"4\"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class=\"carousel-inner\" role=\"listbox\">
                        <div class=\"item active\" >
                            <img src=\"./pic/Home Page.png\" alt=\"\" >
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Sign Up.png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Sign Up With Email.png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Add a Project.png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Project List.png\" alt=\"\">
                        </div>
                    </div>

                    <!-- Controls -->
                    <a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\">
                        <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden="true"></span>";?>
                        <?php echo "<span class=\"sr-only\">Previous</span>
                    </a>
                    <a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\">
                        <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden="true"></span>";?>
                        <?php echo "<span class=\"sr-only\">Next</span>
                    </a>
                </div>
            </div>";?>
            <hr>
            <hr>
            <?php echo "<h4>Secondly, after the project is successfully added, the project is submitted through two main ways.
                First, after logging in, you can enter the Bloom Festival through the Browse Festival in the top menu
                bar, where you can read the major film festivals and the banner at the top of the page and the project
                bar on the right to commit projects immediately; second, you can submit projects immediately; second,
                you can use View Festival in Brown Festival Go to the individual film festival page of interest, where
                there are also instructions for submitting projects. In addition, you can modify and preview the
                submitted items after committing. After selecting a submitted project, you need to select the project
                type, the cost criteria last, and fill in and select Additive information.</h4><a
                href=\"./rongzhan-document.docx\">learn more</a>
            <hr>
            <div class=\"container\">
                <!-- banner -->
                <div id=\"carousel-example-generic\" class=\"carousel slide contanier\" data-ride=\"carousel\">
                    <!-- Indicators -->
                    <ol class=\"carousel-indicators\">
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"3\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"4\"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class=\"carousel-inner\" role=\"listbox\">
                        <div class=\"item active\">
                            <img src=\"./pic/FilmFreeway-Browse Festivals.png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/View Festival.png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Edit Created Project.png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Edit Project Privacy .png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Marketing Options (sales pitch).png\" alt=\"\">
                        </div>
                    </div>

                    <!-- Controls -->
                    <a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\">
                        <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden=\"true\"></span>
                        <span class=\"sr-only\">Previous</span>
                    </a>
                    <a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\">
                        <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden="true"></span>";?>
                        <?php echo "<span class=\"sr-only\">Next</span>
                    </a>
                </div>
            </div>";?>
            <hr>
            <hr>
            <?php echo "<h4>Finally, complete the commit section, divided into two parts, first need to checkout, on this page, the
                web page will show the total cost, Submission Protection and Secure Checkout After completing this step,
                you need to pay for this order and then complete this orde.</h4><a href=\"./rongzhan-document.docx\">learn
                more</a>
            <hr>
            <div class=\"container\">
                <!-- banner -->
                <div id=\"carousel-example-generic\" class=\"carousel slide contanier\" data-ride=\"carousel\">
                    <!-- Indicators -->
                    <ol class=\"carousel-indicators\">
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"0\" class=\"active\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"1\"></li>
                        <li data-target=\"#carousel-example-generic\" data-slide-to=\"2\"></li>
                    </ol>

                    <!-- Wrapper for slides -->
                    <div class=\"carousel-inner\" role=\"listbox\">
                        <div class=\"item active\">
                            <img src=\"./pic/Submitting Your Project.png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Submitting Your Project - supplementary questions.png\" alt=\"\">
                        </div>
                        <div class=\"item\">
                            <img src=\"./pic/Checkout.png\" alt=\"\">
                        </div>
                    </div>

                    <!-- Controls -->
                    <a class=\"left carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"prev\">
                        <span class=\"glyphicon glyphicon-chevron-left\" aria-hidden="true"></span>";?>
                        <?php echo "<span class="sr-only">Previous</span>
                    </a>";?>
                    <?php echo "<a class=\"right carousel-control\" href=\"#carousel-example-generic\" role=\"button\" data-slide=\"next\">
                        <span class=\"glyphicon glyphicon-chevron-right\" aria-hidden="true"></span>";?>
                        <?php echo "<span class=\"sr-only\">Next</span>
                    </a>
                </div>
            </div>
        </div>";?>
        <!-- Mobile devices -->
        <?php echo "<div class=\"page-header container\">
            <h1>Design the final steps</h1>
            <hr>
            <div class=\"container\">
                <h4 id=\"design-b\">Balsamiq wireframes</h4>
                <div class=\"container\" id=\"mobile-amazon\">
                    <img src=\"./pic/Final Step ( Failed ).png\" alt=\"\" class=\"container\">
                    <img src=\"./pic/Final Step - Successful.png\" alt=\"\" class=\"container\">
                    <img src=\"./pic/Log Out.png\" alt=\"\" class=\"container\">
                </div>
            </div>";?>
            <?php echo "<hr>
            <hr>
            <div class=\"container\">
                <h2 id=\"design-d\">Documentation</h2>
                <h3>
                    In the design of the completed order after the final checkout, we envision that there may be two situations, the first is that the payment is successful, the order is completed, and the project is submitted smoothly. In the design of this page, we used icon, Subtitle, label, button, Link Bar. If the payment is successful, the page will have two options, View your submission and Browse more festivals, for the user to return to continue browsing and viewing. Moreover, users can also click on the icon in the top menu bar in the upper right corner to view the functions, such as View Profile, Account Settings, Log Out. Conversely, if the payment is not successful, the order is not completed, and the project is not submitted smoothly. Well, on this failed page, we take a combination of AlterBox and icon and The Link Box. Users need to click on the Reeturn to payment page link and make a new payment.
                </h3>
                <a href=\"./rongzhan-document.docx\">learn more</a>
            </div>
        </div>
        <hr class=\"festurette-divider\">";?>
        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <?php echo "<script src=\"https://code.jquery.com/jquery-1.12.4.min.js\"
            integrity=\"sha384-nvAa0+6Qg9clwYCGGPpDQLVpLNn0fRaROjHqs13t4Ggj3Ez50XnGQqc/r8MhnRDZ\" crossorigin=\"anonymous\">
        </script>";?>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <?php echo "<script src=\"https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"
            integrity=\"sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd\" crossorigin=\"anonymous\">
        </script>";?>
</body>
</html>
<? include("footer.php");?>